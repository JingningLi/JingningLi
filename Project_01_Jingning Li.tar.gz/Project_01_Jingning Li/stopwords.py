#!/usr/bin/env python

"""
A filter that remove stop words.
"""

import fileinput


def process(line):
    stop_words = set(["it", "she", "in", "to", "for", "with", "a", "and", "the", "is"])
    stopwords = "Done"
    while True:
        line = input()
        if line.strip() == stopwords:
            break
        print (" ", join(word for word in line.split() if word not in stop_words)


for line in fileinput.input():
    process(line)
