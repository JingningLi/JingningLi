#!/usr/bin/env python

"""
A filter that performs a count of the top ten unique words.
"""

import fileinput


def process(line):
    symbol = ['']
    symbol1 = [',', '.', '\n', ':', '*', '\t', 'r', None]
    j = ''
    for i in line:
        for i not in symbol:
            if i not in symbol1:
                j=j+1
            if i in symbol:
                j=j+'\n'
            if i in symbol2:
                j=j
    print(j)


for line in fileinput.input():
    process(file)
