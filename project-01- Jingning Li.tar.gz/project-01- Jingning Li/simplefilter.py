#!/usr/bin/env python

"""
A filter that _____performs a count of the top ten unique words in Little Women____.
"""

import fileinput


def process(line):
    """For each line of input, _____."""
    !cat women.txt | grep -oE '\w{{2,}}' | tr '[:upper:]' '[lower:]' |sort | uniq -c | sort -rn | head -10
    


for line in fileinput.input():
    process(line)
